
-- Add license_url column to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS license_url text;

-- Create private bucket for license files
INSERT INTO storage.buckets (id, name, public)
VALUES ('licenses', 'licenses', false)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS: each user can only access files under their own user id folder
CREATE POLICY "Users can view own license"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'licenses' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can upload own license"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'licenses' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update own license"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'licenses' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own license"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'licenses' AND auth.uid()::text = (storage.foldername(name))[1]);
