
-- Allow users to set their own license_url; admins keep full control
CREATE OR REPLACE FUNCTION public.prevent_profile_privilege_escalation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;

  IF NEW.role IS DISTINCT FROM OLD.role THEN
    RAISE EXCEPTION 'Only admins can change role';
  END IF;

  IF NEW.license_submitted IS DISTINCT FROM OLD.license_submitted THEN
    RAISE EXCEPTION 'Only admins can change license_submitted';
  END IF;

  -- license_url may now be set/updated by the owner (file upload flow).
  -- Storage RLS already restricts who can upload to which path.

  RETURN NEW;
END;
$function$;

-- Admin can view any license file in storage
CREATE POLICY "Admins can view all licenses"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'licenses' AND public.has_role(auth.uid(), 'admin'::public.app_role));
