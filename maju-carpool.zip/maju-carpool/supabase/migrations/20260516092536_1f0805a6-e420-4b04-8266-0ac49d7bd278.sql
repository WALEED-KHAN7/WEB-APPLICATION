
-- Trigger: prevent non-admins from elevating their own role / verification / license url
CREATE OR REPLACE FUNCTION public.prevent_profile_privilege_escalation()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Admins can change anything
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;

  -- Non-admins must not change protected fields
  IF NEW.role IS DISTINCT FROM OLD.role THEN
    RAISE EXCEPTION 'Only admins can change role';
  END IF;

  IF NEW.license_submitted IS DISTINCT FROM OLD.license_submitted THEN
    RAISE EXCEPTION 'Only admins can change license_submitted';
  END IF;

  IF NEW.license_url IS DISTINCT FROM OLD.license_url THEN
    RAISE EXCEPTION 'Only admins can change license_url';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_prevent_privilege_escalation ON public.profiles;
CREATE TRIGGER profiles_prevent_privilege_escalation
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_profile_privilege_escalation();

-- Restrict SELECT: split broad-read into "safe view" semantics by removing license_url visibility for non-owners.
-- Since Postgres RLS cannot do per-column, we drop the existing broad policy and create:
--   1. Owner + admin: can see all columns including license_url
--   2. Other authenticated users: can see all columns EXCEPT license_url (enforced by revoking column SELECT)

DROP POLICY IF EXISTS "Authenticated can view profiles" ON public.profiles;

CREATE POLICY "Authenticated can view profiles"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (true);

-- Column-level: revoke license_url from authenticated, then grant only to service_role.
-- Owner/admin reads of license_url must go through a SECURITY DEFINER function.
REVOKE SELECT (license_url) ON public.profiles FROM authenticated;

CREATE OR REPLACE FUNCTION public.get_my_license_url()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT license_url FROM public.profiles WHERE id = auth.uid();
$$;

GRANT EXECUTE ON FUNCTION public.get_my_license_url() TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_get_license_url(_user_id uuid)
RETURNS TEXT
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Only admins can read other users license URLs';
  END IF;
  RETURN (SELECT license_url FROM public.profiles WHERE id = _user_id);
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_get_license_url(uuid) TO authenticated;
