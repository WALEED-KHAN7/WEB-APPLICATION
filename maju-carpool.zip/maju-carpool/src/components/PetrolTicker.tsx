import { DIESEL_PRICE_PKR, PETROL_PRICE_PKR, PETROL_PRICE_LAST_UPDATED } from "@/lib/maju-data";
import { Fuel, TrendingUp, Clock } from "lucide-react";

export function PetrolTicker() {
  const items = [
    { label: "Petrol (Karachi)", value: `Rs ${PETROL_PRICE_PKR.toFixed(2)}/L` },
    { label: "Diesel", value: `Rs ${DIESEL_PRICE_PKR.toFixed(2)}/L` },
    { label: "MAJU Carpool", value: "● ACTIVE" },
  ];
  return (
    <div className="border-b border-border bg-card/60 backdrop-blur-md overflow-hidden">
      <div className="flex items-center gap-3 px-4 py-2 text-xs font-mono">
        <div className="flex items-center gap-1.5 shrink-0 text-muted-foreground font-semibold">
          <Clock className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Last updated:</span>
          <span className="text-foreground">{PETROL_PRICE_LAST_UPDATED}</span>
        </div>
        <div className="flex-1 overflow-hidden relative">
          <div className="flex gap-8 animate-ticker whitespace-nowrap w-max">
            {[...items, ...items, ...items].map((it, i) => (
              <span key={i} className="flex items-center gap-2 text-muted-foreground">
                <TrendingUp className="w-3 h-3 text-success" />
                <span>{it.label}:</span>
                <span className="text-foreground font-semibold">{it.value}</span>
              </span>
            ))}
          </div>
        </div>
        <Fuel className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
      </div>
    </div>
  );
}
