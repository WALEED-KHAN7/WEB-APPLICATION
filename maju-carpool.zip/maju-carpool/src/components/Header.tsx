import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { Car, LogOut, Shield } from "lucide-react";
import { useAuth } from "@/lib/use-user";
import { useRole } from "@/lib/use-role";
import { QRCodeCard } from "@/components/QRCodeCard";

export function Header() {
  const { user, signOut } = useAuth();
  const { isAdmin } = useRole();
  const loc = useLocation();
  const navigate = useNavigate();

  async function handleSignOut() {
    await signOut();
    navigate({ to: "/" });
  }

  return (
    <header className="sticky top-0 z-40 glass border-b border-border">
      <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-lg bg-gradient-primary flex items-center justify-center shadow-glow group-hover:scale-105 transition-smooth">
            <Car className="w-5 h-5 text-primary-foreground" />
          </div>
          <div className="leading-tight">
            <div className="font-bold text-base tracking-tight">MAJU <span className="text-gradient">CARPOOL</span></div>
            <div className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest">Shahrah-e-Faisal</div>
          </div>
        </Link>
        <nav className="flex items-center gap-1 text-sm">
          <div className="hidden sm:block mr-1"><QRCodeCard /></div>
          {user ? (
            <>
              <Link to="/dashboard" className={`px-3 py-1.5 rounded-md transition-smooth ${loc.pathname === "/dashboard" ? "bg-primary/20 text-primary-glow" : "hover:bg-secondary"}`}>Dashboard</Link>
              <Link to="/register" className={`px-3 py-1.5 rounded-md transition-smooth ${loc.pathname === "/register" ? "bg-primary/20 text-primary-glow" : "hover:bg-secondary"}`}>Profile</Link>
              {isAdmin && (
                <Link to="/admin" className={`px-3 py-1.5 rounded-md transition-smooth flex items-center gap-1 ${loc.pathname === "/admin" ? "bg-primary/20 text-primary-glow" : "hover:bg-secondary"}`}>
                  <Shield className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Admin</span>
                </Link>
              )}
              <button
                onClick={handleSignOut}
                className="px-3 py-1.5 rounded-md hover:bg-destructive/20 hover:text-destructive transition-smooth flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Sign out</span>
              </button>
            </>
          ) : (
            <Link to="/auth" className="px-4 py-1.5 rounded-md bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:scale-105 transition-smooth">
              Sign in
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
