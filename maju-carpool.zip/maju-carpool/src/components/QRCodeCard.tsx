import { QRCodeSVG } from "qrcode.react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { QrCode, Copy, Check } from "lucide-react";

const APP_URL = "https://httpsmaju-carpoolme.lovable.app";

export function QRCodeCard() {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    await navigator.clipboard.writeText(APP_URL);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen(true)}
        className="gap-2"
      >
        <QrCode className="h-4 w-4" />
        Share via QR
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md flex flex-col items-center text-center">
          <DialogHeader className="items-center">
            <DialogTitle>Open MAJU Carpool</DialogTitle>
            <DialogDescription>Scan with any phone camera</DialogDescription>
          </DialogHeader>

          <div className="bg-white p-5 rounded-2xl shadow-lg">
            <QRCodeSVG
              value={APP_URL}
              size={240}
              level="H"
              includeMargin={false}
            />
          </div>

          <div className="w-full bg-muted rounded-lg p-3 text-xs font-mono break-all text-muted-foreground">
            {APP_URL}
          </div>

          <div className="flex gap-3 w-full">
            <Button onClick={copy} className="flex-1 gap-2" variant="secondary">
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              {copied ? "Copied!" : "Copy link"}
            </Button>
            <Button onClick={() => setOpen(false)} className="flex-1">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
