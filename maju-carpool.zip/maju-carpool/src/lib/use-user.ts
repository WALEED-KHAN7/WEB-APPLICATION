import { useEffect, useState } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { PETROL_PRICE_PKR } from "@/lib/maju-data";

export type Role = "driver" | "passenger";

export type Profile = {
  id: string;
  name: string;
  phone: string | null;
  role: Role | null;
  pickup_id: string | null;
  shift_id: string | null;
  vehicle: string | null;
  average_kmpl: number | null;
  seats_available: number | null;
  license_submitted: boolean;
  license_url?: string | null;
  profile_completed: boolean;
};

/**
 * Auth hook — exposes the current user + their profile row.
 * Uses Supabase onAuthStateChange (set up BEFORE getSession).
 */
export function useAuth() {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 1. Subscribe FIRST to avoid race conditions
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      setUser(sess?.user ?? null);
      if (!sess?.user) {
        setProfile(null);
        setLoading(false);
      }
    });

    // 2. THEN check existing session
    supabase.auth.getSession().then(({ data: { session: sess } }) => {
      setSession(sess);
      setUser(sess?.user ?? null);
      if (!sess?.user) setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Fetch profile whenever user changes
  useEffect(() => {
    if (!user) return;
    let active = true;
    (async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();
      if (!active) return;
      if (error) console.error("[profile fetch]", error);
      setProfile((data as Profile) ?? null);
      setLoading(false);
    })();
    return () => { active = false; };
  }, [user]);

  async function signOut() {
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
    setProfile(null);
  }

  return { session, user, profile, loading, signOut, refreshProfile: async () => {
    if (!user) return;
    const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
    setProfile((data as Profile) ?? null);
  }};
}

/**
 * Mock live petrol price ticker — slight random fluctuation around base.
 */
export function usePetrolPrice() {
  const [price, setPrice] = useState(PETROL_PRICE_PKR);
  useEffect(() => {
    const interval = setInterval(() => {
      const delta = (Math.random() - 0.5) * 0.6;
      setPrice((p) => Math.max(200, +(p + delta).toFixed(2)));
    }, 4000);
    return () => clearInterval(interval);
  }, []);
  return price;
}
