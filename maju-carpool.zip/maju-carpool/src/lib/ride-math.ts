import { PETROL_PRICE_PKR } from "@/lib/maju-data";

/**
 * Cost split formula:
 *   total fuel cost = (distance / vehicle average) * petrol price
 *   per person = total / (passengers + 1 driver)
 * Distance is round trip (pickup -> MAJU -> pickup) = 2 * one-way distance.
 */
export function computeRideCost(opts: {
  oneWayKm: number;
  averageKmpl: number;
  totalPeople: number; // driver + passengers
  petrolPrice?: number;
}) {
  const petrol = opts.petrolPrice ?? PETROL_PRICE_PKR;
  const distance = opts.oneWayKm * 2;
  const litres = distance / opts.averageKmpl;
  const totalCost = litres * petrol;
  const perPerson = totalCost / Math.max(opts.totalPeople, 1);
  return {
    distance,
    litres,
    totalCost,
    perPerson,
    petrol,
  };
}

export const fmtPKR = (n: number) =>
  `Rs ${n.toLocaleString("en-PK", { maximumFractionDigits: 0 })}`;
