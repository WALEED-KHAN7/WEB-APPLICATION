// MAJU University location: Main Shahrah-e-Faisal, Karachi
// Distances are approximate one-way road distances in km from each pickup point to MAJU.

export type PickupPoint = {
  id: string;
  name: string;
  area: string;
  distanceKm: number; // one-way to MAJU
};

export const PICKUP_POINTS: PickupPoint[] = [
  { id: "nipa", name: "NIPA (Mazaidar Haleem)", area: "NIPA Chowrangi", distanceKm: 9.5 },
  { id: "nursery", name: "Nursery (KFC)", area: "Shahrah-e-Faisal", distanceKm: 4.2 },
  { id: "millennium", name: "Millennium Mall (Main Gate)", area: "Shahrah-e-Faisal", distanceKm: 6.8 },
  { id: "drigh", name: "Drigh Road (Station Entrance)", area: "Drigh Road", distanceKm: 7.5 },
  { id: "stargate", name: "Star Gate (Pedestrian Bridge)", area: "Shahrah-e-Faisal", distanceKm: 11.2 },
  { id: "sohrab", name: "Sohrab Goth (Al-Asif)", area: "Super Highway", distanceKm: 14.6 },
  { id: "karsaz", name: "Karsaz (HBL)", area: "Shahrah-e-Faisal", distanceKm: 5.1 },
];

export const SHIFTS = [
  { id: "morning-8", label: "Morning — 8:00 AM" },
  { id: "morning-10", label: "Morning — 10:00 AM" },
  { id: "noon-12", label: "Noon — 12:00 PM" },
  { id: "afternoon-2", label: "Afternoon — 2:00 PM" },
  { id: "evening-4", label: "Evening — 4:00 PM" },
  { id: "evening-6", label: "Evening — 6:00 PM" },
];

// Mock pool of fellow students (drivers + passengers) seeded across pickup points
export type PoolUser = {
  id: string;
  name: string;
  role: "driver" | "passenger";
  pickupId: string;
  shiftId: string;
  vehicle?: string;
  averageKmpl?: number; // km per litre
  seatsAvailable?: number;
  verified?: boolean; // license submitted
};

export const POOL: PoolUser[] = [
  { id: "u1", name: "Ahmed Raza", role: "driver", pickupId: "nipa", shiftId: "morning-8", vehicle: "Honda City 2019", averageKmpl: 13, seatsAvailable: 3, verified: true },
  { id: "u2", name: "Sara Khan", role: "passenger", pickupId: "nipa", shiftId: "morning-8" },
  { id: "u3", name: "Bilal Ahmed", role: "passenger", pickupId: "nipa", shiftId: "morning-8" },
  { id: "u4", name: "Hassan Ali", role: "driver", pickupId: "nursery", shiftId: "morning-10", vehicle: "Suzuki Cultus 2021", averageKmpl: 15, seatsAvailable: 2, verified: true },
  { id: "u5", name: "Ayesha Iqbal", role: "passenger", pickupId: "nursery", shiftId: "morning-10" },
  { id: "u6", name: "Zain Malik", role: "driver", pickupId: "millennium", shiftId: "noon-12", vehicle: "Toyota Corolla 2020", averageKmpl: 12, seatsAvailable: 4, verified: false },
  { id: "u7", name: "Fatima Sheikh", role: "passenger", pickupId: "millennium", shiftId: "noon-12" },
  { id: "u8", name: "Usman Tariq", role: "passenger", pickupId: "millennium", shiftId: "noon-12" },
  { id: "u9", name: "Hira Naveed", role: "driver", pickupId: "drigh", shiftId: "afternoon-2", vehicle: "Honda Civic 2018", averageKmpl: 11, seatsAvailable: 3, verified: true },
  { id: "u10", name: "Daniyal Shah", role: "passenger", pickupId: "drigh", shiftId: "afternoon-2" },
  { id: "u11", name: "Maryam Yousuf", role: "driver", pickupId: "stargate", shiftId: "evening-4", vehicle: "KIA Picanto 2022", averageKmpl: 16, seatsAvailable: 2, verified: true },
  { id: "u12", name: "Saad Hussain", role: "passenger", pickupId: "stargate", shiftId: "evening-4" },
  { id: "u13", name: "Imran Qureshi", role: "driver", pickupId: "sohrab", shiftId: "morning-8", vehicle: "Suzuki Swift 2020", averageKmpl: 14, seatsAvailable: 3, verified: true },
  { id: "u14", name: "Noor Fatima", role: "passenger", pickupId: "sohrab", shiftId: "morning-8" },
  { id: "u15", name: "Talha Bashir", role: "passenger", pickupId: "sohrab", shiftId: "morning-8" },
  { id: "u16", name: "Aiman Zafar", role: "driver", pickupId: "karsaz", shiftId: "evening-6", vehicle: "Honda BR-V 2021", averageKmpl: 10, seatsAvailable: 5, verified: false },
  { id: "u17", name: "Hamza Siddiqui", role: "passenger", pickupId: "karsaz", shiftId: "evening-6" },
];

// Current petrol price PKR/litre (snapshot — not live)
export const PETROL_PRICE_PKR = 414.78;
export const DIESEL_PRICE_PKR = 414.58;
export const PETROL_PRICE_LAST_UPDATED = "14 May 2026";
