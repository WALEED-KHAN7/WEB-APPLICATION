import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Header } from "@/components/Header";
import { PetrolTicker } from "@/components/PetrolTicker";
import { PICKUP_POINTS, SHIFTS } from "@/lib/maju-data";
import { useAuth } from "@/lib/use-user";
import { supabase } from "@/integrations/supabase/client";
import { ArrowRight, AlertCircle, Loader2, ShieldCheck, Car, Users, Upload, FileCheck2, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Complete Profile — MAJU Carpool" },
      { name: "description", content: "Tell us your pickup point and shift. An admin will assign your ride role." },
    ],
  }),
  component: RegisterPage,
});

const schema = z.object({
  name: z.string().trim().min(2, "Name too short").max(80),
  phone: z.string().trim().max(20).optional().or(z.literal("")),
  pickupId: z.string().min(1, "Select a pickup point"),
  shiftId: z.string().min(1, "Select a class shift"),
  role: z.enum(["driver", "passenger"], { message: "Select your role" }),
  vehicle: z.string().trim().max(80).optional().or(z.literal("")),
  averageKmpl: z.string().optional().or(z.literal("")),
  seatsAvailable: z.string().optional().or(z.literal("")),
});

function RegisterPage() {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading, refreshProfile } = useAuth();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");
  const [role, setRole] = useState<"driver" | "passenger" | "">(
    (profile?.role as "driver" | "passenger" | undefined) ?? ""
  );
  const [licenseFile, setLicenseFile] = useState<File | null>(null);
  const [uploadingLicense, setUploadingLicense] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      toast.error("Please sign in first.");
      navigate({ to: "/auth" });
    }
  }, [authLoading, user, navigate]);

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary-glow" />
      </div>
    );
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setServerError("");
    const fd = new FormData(e.currentTarget);
    const raw = {
      name: String(fd.get("name") ?? ""),
      phone: String(fd.get("phone") ?? ""),
      pickupId: String(fd.get("pickupId") ?? ""),
      shiftId: String(fd.get("shiftId") ?? ""),
      role: String(fd.get("role") ?? ""),
      vehicle: String(fd.get("vehicle") ?? ""),
      averageKmpl: String(fd.get("averageKmpl") ?? ""),
      seatsAvailable: String(fd.get("seatsAvailable") ?? ""),
    };
    const parsed = schema.safeParse(raw);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const issue of parsed.error.issues) errs[issue.path[0] as string] = issue.message;
      setErrors(errs);
      return;
    }
    setErrors({});
    setSubmitting(true);

    const d = parsed.data;

    let licenseUrl: string | undefined = undefined;
    if (d.role === "driver" && licenseFile) {
      setUploadingLicense(true);
      const ext = licenseFile.name.split(".").pop() || "bin";
      const path = `${user!.id}/license-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from("licenses")
        .upload(path, licenseFile, { upsert: true, contentType: licenseFile.type });
      setUploadingLicense(false);
      if (upErr) {
        setServerError(`License upload failed: ${upErr.message}`);
        setSubmitting(false);
        return;
      }
      licenseUrl = path;
    }

    const baseUpdate = {
      name: d.name,
      phone: d.phone || null,
      pickup_id: d.pickupId,
      shift_id: d.shiftId,
      role: d.role,
      profile_completed: true,
      vehicle: d.role === "driver" ? (d.vehicle || null) : null,
      average_kmpl: d.role === "driver" && d.averageKmpl ? Number(d.averageKmpl) : null,
      seats_available: d.role === "driver" && d.seatsAvailable ? Number(d.seatsAvailable) : null,
      ...(licenseUrl ? { license_url: licenseUrl } : {}),
    };

    const { error } = await supabase.from("profiles").update(baseUpdate).eq("id", user!.id);

    if (error) {
      setServerError(error.message);
      setSubmitting(false);
      return;
    }
    await refreshProfile();
    toast.success(
      d.role === "driver" && licenseUrl
        ? "Profile saved. License submitted for admin verification."
        : `Profile saved as ${d.role}`
    );
    navigate({ to: "/dashboard" });
  }

  return (
    <div className="min-h-screen">
      <PetrolTicker />
      <Header />
      <div className="mx-auto max-w-2xl px-4 py-10 sm:py-14">
        <div className="mb-8">
          <div className="text-xs font-mono uppercase tracking-widest text-primary-glow mb-2">
            Step 02 / Complete Profile
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold">Tell us about your commute</h1>
          <p className="text-muted-foreground mt-2 text-sm">
            Signed in as <span className="text-foreground font-mono">{user.email}</span>.
          </p>
        </div>

        <form onSubmit={onSubmit} className="glass rounded-2xl p-6 sm:p-8 space-y-6 shadow-card">
          <Field label="I want to join as" error={errors.role}>
            <div className="grid grid-cols-2 gap-3">
              <RoleOption
                icon={Car} label="Driver" hint="I have a car & offer rides"
                checked={role === "driver"} onSelect={() => setRole("driver")} name="role" value="driver"
              />
              <RoleOption
                icon={Users} label="Passenger" hint="I need a ride"
                checked={role === "passenger"} onSelect={() => setRole("passenger")} name="role" value="passenger"
              />
            </div>
          </Field>

          <Field label="Full Name" error={errors.name}>
            <input name="name" defaultValue={profile?.name ?? ""} placeholder="Ahmed Khan" className={inputCls} required />
          </Field>

          <Field label="Phone / WhatsApp (optional)" hint="Shared only with matched riders" error={errors.phone}>
            <input name="phone" defaultValue={profile?.phone ?? ""} placeholder="+92 300 1234567" className={inputCls} />
          </Field>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Pickup Point" error={errors.pickupId}>
              <select name="pickupId" defaultValue={profile?.pickup_id ?? ""} className={inputCls} required>
                <option value="" disabled>Select pickup…</option>
                {PICKUP_POINTS.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} ({p.distanceKm} km)</option>
                ))}
              </select>
            </Field>
            <Field label="Class Shift" error={errors.shiftId}>
              <select name="shiftId" defaultValue={profile?.shift_id ?? ""} className={inputCls} required>
                <option value="" disabled>Select shift…</option>
                {SHIFTS.map((s) => (
                  <option key={s.id} value={s.id}>{s.label}</option>
                ))}
              </select>
            </Field>
          </div>

          {role === "driver" && (
            <div className="grid sm:grid-cols-3 gap-4 rounded-xl border border-primary/30 bg-primary/5 p-4">
              <Field label="Vehicle">
                <input name="vehicle" defaultValue={profile?.vehicle ?? ""} placeholder="Honda City 2019" className={inputCls} />
              </Field>
              <Field label="Avg km/L">
                <input name="averageKmpl" type="number" step="0.1" min="1" max="40" defaultValue={profile?.average_kmpl ?? ""} placeholder="13" className={inputCls} />
              </Field>
              <Field label="Seats">
                <input name="seatsAvailable" type="number" min="1" max="6" defaultValue={profile?.seats_available ?? ""} placeholder="3" className={inputCls} />
              </Field>
              <div className="sm:col-span-3">
                <Label>Driving License (image or PDF)</Label>
                <div className="mt-1.5">
                  <label className="flex items-center gap-3 px-3.5 py-2.5 rounded-lg bg-input border border-dashed border-border hover:border-primary/60 cursor-pointer transition-smooth">
                    <Upload className="w-4 h-4 text-primary-glow" />
                    <span className="text-sm text-muted-foreground flex-1 truncate">
                      {licenseFile ? licenseFile.name : profile?.license_url ? "Replace submitted license…" : "Upload your license for admin verification"}
                    </span>
                    {profile?.license_submitted && (
                      <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-success/15 text-success border border-success/30 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Verified
                      </span>
                    )}
                    {!profile?.license_submitted && profile?.license_url && (
                      <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                        <FileCheck2 className="w-3 h-3" /> Pending review
                      </span>
                    )}
                    <input
                      type="file"
                      accept="image/*,application/pdf"
                      className="hidden"
                      onChange={(e) => setLicenseFile(e.target.files?.[0] ?? null)}
                    />
                  </label>
                </div>
              </div>
              <div className="sm:col-span-3 text-[11px] text-muted-foreground flex items-center gap-1.5">
                <ShieldCheck className="w-3 h-3" /> An admin will review your license and mark your profile as verified.
                {uploadingLicense && <span className="ml-2 inline-flex items-center gap-1 text-primary-glow"><Loader2 className="w-3 h-3 animate-spin" /> Uploading…</span>}
              </div>
            </div>
          )}

          {serverError && (
            <div className="flex items-start gap-2 text-xs text-destructive p-2.5 rounded-md bg-destructive/10 border border-destructive/30">
              <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              <span>{serverError}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full inline-flex items-center justify-center gap-2 py-3.5 rounded-lg bg-gradient-primary text-primary-foreground font-semibold shadow-elevated hover:scale-[1.01] transition-smooth disabled:opacity-50"
          >
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <>Save Profile <ArrowRight className="w-4 h-4" /></>}
          </button>

          <div className="text-center">
            <Link to="/dashboard" className="text-xs text-muted-foreground hover:text-foreground">Skip for now →</Link>
          </div>
        </form>
      </div>
    </div>
  );
}

const inputCls = "w-full px-3.5 py-2.5 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-smooth";

function Label({ children }: { children: React.ReactNode }) {
  return <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{children}</div>;
}

function Field({ label, hint, error, children }: { label: string; hint?: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <Label>{label}</Label>
      <div className="mt-1.5">{children}</div>
      {hint && !error && <div className="text-xs text-muted-foreground mt-1">{hint}</div>}
      {error && (
        <div className="text-xs text-destructive mt-1 flex items-center gap-1">
          <AlertCircle className="w-3 h-3" /> {error}
        </div>
      )}
    </div>
  );
}

function RoleOption({
  icon: Icon, label, hint, checked, onSelect, name, value,
}: {
  icon: any; label: string; hint: string; checked: boolean; onSelect: () => void; name: string; value: string;
}) {
  return (
    <label
      className={`cursor-pointer rounded-xl border p-4 flex items-start gap-3 transition-smooth ${
        checked ? "border-primary bg-primary/10 shadow-glow" : "border-border bg-card/40 hover:border-primary/40"
      }`}
    >
      <input
        type="radio"
        name={name}
        value={value}
        checked={checked}
        onChange={onSelect}
        className="sr-only"
      />
      <Icon className={`w-5 h-5 mt-0.5 ${checked ? "text-primary-glow" : "text-muted-foreground"}`} />
      <div>
        <div className="font-semibold text-sm">{label}</div>
        <div className="text-[11px] text-muted-foreground">{hint}</div>
      </div>
    </label>
  );
}
