import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Header } from "@/components/Header";
import { PetrolTicker } from "@/components/PetrolTicker";
import { Car, ArrowRight, AlertCircle, Mail, Lock, User as UserIcon, Loader2, Eye, EyeOff, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign In — MAJU Carpool" },
      { name: "description", content: "Sign in or create a MAJU Carpool account." },
    ],
  }),
  component: AuthPage,
});

const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email("Invalid email")
  .max(255)
  .refine((v) => v.endsWith("@maju.edu.pk"), {
    message: "Only MAJU student emails are allowed.",
  });
const passwordSchema = z.string().min(6, "Password must be at least 6 characters").max(72);

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);

  // If already logged in, redirect to dashboard
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) navigate({ to: "/dashboard" });
    });
  }, [navigate]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setInfo("");

    const emailParsed = emailSchema.safeParse(email);
    if (!emailParsed.success) return setError(emailParsed.error.issues[0].message);

    if (mode === "forgot") {
      setLoading(true);
      try {
        const { error: err } = await supabase.auth.resetPasswordForEmail(emailParsed.data, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (err) throw err;
        setInfo("Password reset link sent! Check your email inbox (and spam folder).");
      } catch (err: any) {
        setError(err?.message || "Could not send reset email");
      } finally {
        setLoading(false);
      }
      return;
    }

    const pwParsed = passwordSchema.safeParse(password);
    if (!pwParsed.success) return setError(pwParsed.error.issues[0].message);

    if (mode === "signup" && password !== confirmPassword) {
      return setError("Passwords do not match");
    }

    setLoading(true);
    try {
      if (mode === "signup") {
        const trimmedName = name.trim();
        if (trimmedName.length < 2) {
          setError("Please enter your full name");
          setLoading(false);
          return;
        }
        const { error: err } = await supabase.auth.signUp({
          email: emailParsed.data,
          password: pwParsed.data,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { name: trimmedName },
          },
        });
        if (err) throw err;
        navigate({ to: "/register" });
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({
          email: emailParsed.data,
          password: pwParsed.data,
        });
        if (err) throw err;
        navigate({ to: "/dashboard" });
      }
    } catch (err: any) {
      setError(err?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  async function onGoogle() {
    setError("");
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: `${window.location.origin}/dashboard`,
    });
    if (result.error) {
      setError(result.error instanceof Error ? result.error.message : "Google sign-in failed");
      setLoading(false);
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/dashboard" });
  }

  const title =
    mode === "signup" ? "Join MAJU Carpool" :
    mode === "forgot" ? "Reset your password" :
    "Sign in to continue";
  const subtitle =
    mode === "signup" ? "Create your account to match with real MAJU students." :
    mode === "forgot" ? "Enter your email and we'll send you a reset link." :
    "Welcome back, ride-sharer.";
  const eyebrow =
    mode === "signup" ? "Step 01 / Sign Up" :
    mode === "forgot" ? "Forgot Password" :
    "Welcome Back";

  return (
    <div className="min-h-screen">
      <PetrolTicker />
      <Header />
      <div className="mx-auto max-w-md px-4 py-12">
        <div className="mb-6 text-center">
          <div className="text-xs font-mono uppercase tracking-widest text-primary-glow mb-2">{eyebrow}</div>
          <h1 className="text-3xl font-bold">{title}</h1>
          <p className="text-sm text-muted-foreground mt-2">{subtitle}</p>
        </div>

        <div className="glass rounded-2xl p-6 sm:p-7 space-y-5 shadow-card">
          {mode !== "forgot" && (
            <>
              <button
                type="button"
                onClick={onGoogle}
                disabled={loading}
                className="w-full inline-flex items-center justify-center gap-3 py-3 rounded-lg bg-white text-slate-900 font-semibold hover:bg-white/90 transition-smooth disabled:opacity-50"
              >
                <GoogleIcon /> Continue with Google
              </button>

              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <div className="flex-1 h-px bg-border" />
                <span>OR</span>
                <div className="flex-1 h-px bg-border" />
              </div>
            </>
          )}

          <form onSubmit={onSubmit} className="space-y-4">
            {mode === "signup" && (
              <Field icon={UserIcon} label="Full Name">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ahmed Khan"
                  className={inputCls}
                  required
                  maxLength={80}
                />
              </Field>
            )}
            <Field icon={Mail} label="Email">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="sp22-bcs-099@student.maju.edu.pk"
                className={inputCls}
                required
                maxLength={255}
              />
            </Field>
            {mode !== "forgot" && (
              <Field icon={Lock} label="Password">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className={inputCls + " pr-10"}
                  required
                  minLength={6}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-smooth"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </Field>
            )}
            {mode === "signup" && (
              <Field icon={Lock} label="Confirm Password">
                <input
                  type={showConfirm ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className={inputCls + " pr-10"}
                  required
                  minLength={6}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-smooth"
                  aria-label={showConfirm ? "Hide password" : "Show password"}
                  tabIndex={-1}
                >
                  {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </Field>
            )}

            {mode === "signin" && (
              <div className="text-right -mt-2">
                <button
                  type="button"
                  onClick={() => { setMode("forgot"); setError(""); setInfo(""); }}
                  className="text-xs text-primary-glow hover:underline font-semibold"
                >
                  Forgot password?
                </button>
              </div>
            )}

            {error && (
              <div className="flex items-start gap-2 text-xs text-destructive p-2.5 rounded-md bg-destructive/10 border border-destructive/30">
                <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}
            {info && (
              <div className="flex items-start gap-2 text-xs text-primary-glow p-2.5 rounded-md bg-primary/10 border border-primary/30">
                <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                <span>{info}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-lg bg-gradient-primary text-primary-foreground font-semibold shadow-glow disabled:opacity-50 transition-smooth"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                <>
                  {mode === "signup" ? "Create Account" : mode === "forgot" ? "Send Reset Link" : "Sign In"}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="text-center text-sm text-muted-foreground">
            {mode === "forgot" ? (
              <>
                Remembered it?{" "}
                <button
                  onClick={() => { setMode("signin"); setError(""); setInfo(""); }}
                  className="text-primary-glow font-semibold hover:underline"
                >
                  Back to sign in
                </button>
              </>
            ) : (
              <>
                {mode === "signup" ? "Already have an account?" : "New to MAJU Carpool?"}{" "}
                <button
                  onClick={() => { setMode(mode === "signup" ? "signin" : "signup"); setError(""); setInfo(""); }}
                  className="text-primary-glow font-semibold hover:underline"
                >
                  {mode === "signup" ? "Sign in" : "Create one"}
                </button>
              </>
            )}
          </div>
        </div>

        <div className="text-center mt-6">
          <Link to="/" className="text-xs text-muted-foreground hover:text-foreground">← Back to home</Link>
        </div>
      </div>
    </div>
  );
}

const inputCls = "w-full pl-10 pr-3.5 py-2.5 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-smooth";

function Field({ icon: Icon, label, children }: { icon: any; label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">{label}</div>
      <div className="relative">
        <Icon className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        {children}
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A10.997 10.997 0 0012 23z"/>
      <path fill="#FBBC05" d="M5.84 14.1A6.59 6.59 0 015.5 12c0-.73.13-1.44.34-2.1V7.06H2.18A10.997 10.997 0 001 12c0 1.77.42 3.45 1.18 4.94l3.66-2.84z"/>
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"/>
    </svg>
  );
}
