import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/Header";
import { PetrolTicker } from "@/components/PetrolTicker";
import { Lock, Eye, EyeOff, AlertCircle, CheckCircle2, Loader2, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [{ title: "Reset Password — MAJU Carpool" }],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Supabase auto-handles the recovery hash and emits a PASSWORD_RECOVERY / SIGNED_IN event
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") setReady(true);
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) setReady(true);
    });
    return () => subscription.unsubscribe();
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(""); setInfo("");
    if (password.length < 6) return setError("Password must be at least 6 characters");
    if (password !== confirm) return setError("Passwords don't match");
    setLoading(true);
    try {
      const { error: err } = await supabase.auth.updateUser({ password });
      if (err) throw err;
      setInfo("Password updated! Redirecting to your dashboard…");
      setTimeout(() => navigate({ to: "/dashboard" }), 1200);
    } catch (err: any) {
      setError(err?.message || "Failed to update password");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen">
      <PetrolTicker />
      <Header />
      <div className="mx-auto max-w-md px-4 py-12">
        <div className="mb-6 text-center">
          <div className="text-xs font-mono uppercase tracking-widest text-primary-glow mb-2">Set New Password</div>
          <h1 className="text-3xl font-bold">Choose a new password</h1>
          <p className="text-sm text-muted-foreground mt-2">Enter and confirm your new password below.</p>
        </div>

        <div className="glass rounded-2xl p-6 sm:p-7 space-y-5 shadow-card">
          {!ready && (
            <div className="flex items-start gap-2 text-xs text-muted-foreground p-2.5 rounded-md bg-secondary/50 border border-border">
              <Loader2 className="w-3.5 h-3.5 mt-0.5 shrink-0 animate-spin" />
              <span>Verifying reset link… If this takes long, request a new link from the sign-in page.</span>
            </div>
          )}

          <form onSubmit={onSubmit} className="space-y-4">
            <PwField label="New Password" value={password} onChange={setPassword} show={show} setShow={setShow} />
            <PwField label="Confirm Password" value={confirm} onChange={setConfirm} show={show} setShow={setShow} />

            {error && (
              <div className="flex items-start gap-2 text-xs text-destructive p-2.5 rounded-md bg-destructive/10 border border-destructive/30">
                <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}
            {info && (
              <div className="flex items-start gap-2 text-xs text-primary-glow p-2.5 rounded-md bg-primary/10 border border-primary/30">
                <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                <span>{info}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !ready}
              className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-lg bg-gradient-primary text-primary-foreground font-semibold shadow-glow disabled:opacity-50 transition-smooth"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (<>Update Password <ArrowRight className="w-4 h-4" /></>)}
            </button>
          </form>
        </div>

        <div className="text-center mt-6">
          <Link to="/auth" className="text-xs text-muted-foreground hover:text-foreground">← Back to sign in</Link>
        </div>
      </div>
    </div>
  );
}

function PwField({ label, value, onChange, show, setShow }: {
  label: string; value: string; onChange: (v: string) => void; show: boolean; setShow: (v: boolean) => void;
}) {
  return (
    <div>
      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">{label}</div>
      <div className="relative">
        <Lock className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="••••••••"
          className="w-full pl-10 pr-10 py-2.5 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-smooth"
          required
          minLength={6}
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-smooth"
          aria-label={show ? "Hide password" : "Show password"}
          tabIndex={-1}
        >
          {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}
