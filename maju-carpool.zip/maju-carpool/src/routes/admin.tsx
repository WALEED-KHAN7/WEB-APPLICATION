import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/use-user";
import { useRole } from "@/lib/use-role";
import { Header } from "@/components/Header";
import { PetrolTicker } from "@/components/PetrolTicker";
import { PICKUP_POINTS, SHIFTS } from "@/lib/maju-data";
import {
  Shield, Trash2, UserCog, Loader2, CheckCircle2, AlertCircle, Car, User, Users,
  ShieldOff, X, Save, Crown, MapPin, Clock, FileCheck2, Eye, XCircle,
} from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [{ title: "Admin Panel — MAJU Carpool" }],
  }),
  component: AdminPage,
});

type Row = {
  id: string;
  name: string;
  phone: string | null;
  role: "driver" | "passenger" | null;
  pickup_id: string | null;
  shift_id: string | null;
  vehicle: string | null;
  average_kmpl: number | null;
  seats_available: number | null;
  license_url: string | null;
  license_submitted: boolean;
  profile_completed: boolean;
  created_at: string;
  is_admin?: boolean;
};

type Tab = "all" | "drivers" | "passengers" | "unassigned" | "admins" | "licenses";

function AdminPage() {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: roleLoading } = useRole();
  const navigate = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [tab, setTab] = useState<Tab>("all");
  const [editing, setEditing] = useState<Row | null>(null);

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/auth" });
  }, [authLoading, user, navigate]);

  async function load() {
    setLoading(true);
    const [profilesRes, rolesRes] = await Promise.all([
      supabase.from("profiles").select("*").order("created_at", { ascending: false }),
      supabase.from("user_roles").select("user_id, role").eq("role", "admin"),
    ]);
    const adminIds = new Set((rolesRes.data ?? []).map((r: any) => r.user_id));
    const merged = ((profilesRes.data ?? []) as Row[]).map((p) => ({ ...p, is_admin: adminIds.has(p.id) }));
    setRows(merged);
    setLoading(false);
  }

  useEffect(() => { if (isAdmin) load(); }, [isAdmin]);

  function flash(type: "ok" | "err", text: string) {
    setMsg({ type, text });
    setTimeout(() => setMsg(null), 4000);
  }

  async function setRole(row: Row, role: "driver" | "passenger" | null) {
    const update: any = { role };
    if (role !== "driver") {
      // Clear driver-only fields when removing driver role
      update.vehicle = null;
      update.average_kmpl = null;
      update.seats_available = null;
      update.license_submitted = false;
    }
    const { error } = await supabase.from("profiles").update(update).eq("id", row.id);
    if (error) return flash("err", error.message);
    flash("ok", `${row.name || "User"} is now ${role ?? "unassigned"}`);
    load();
  }

  async function toggleAdmin(row: Row) {
    if (row.is_admin) {
      const { error } = await supabase.from("user_roles").delete().eq("user_id", row.id).eq("role", "admin");
      if (error) return flash("err", error.message);
      flash("ok", `${row.name} is no longer an admin`);
    } else {
      const { error } = await supabase.from("user_roles").insert({ user_id: row.id, role: "admin" });
      if (error) return flash("err", error.message);
      flash("ok", `${row.name} promoted to admin`);
    }
    load();
  }

  async function deleteProfile(row: Row) {
    if (!confirm(`Delete ${row.name || "this user"}'s profile? This removes them from carpool listings.`)) return;
    const { error } = await supabase.from("profiles").delete().eq("id", row.id);
    if (error) return flash("err", error.message);
    flash("ok", `${row.name || "Profile"} deleted`);
    load();
  }

  async function toggleVerify(row: Row) {
    if (row.role !== "driver") return flash("err", "Only drivers can be verified");
    const { error } = await supabase.from("profiles").update({ license_submitted: !row.license_submitted }).eq("id", row.id);
    if (error) return flash("err", error.message);
    flash("ok", `Verification ${!row.license_submitted ? "granted" : "revoked"} for ${row.name}`);
    load();
  }

  const filtered = useMemo(() => {
    switch (tab) {
      case "drivers": return rows.filter(r => r.role === "driver");
      case "passengers": return rows.filter(r => r.role === "passenger");
      case "unassigned": return rows.filter(r => !r.role);
      case "admins": return rows.filter(r => r.is_admin);
      case "licenses": return rows.filter(r => !!r.license_url);
      default: return rows;
    }
  }, [rows, tab]);

  const counts = useMemo(() => ({
    all: rows.length,
    drivers: rows.filter(r => r.role === "driver").length,
    passengers: rows.filter(r => r.role === "passenger").length,
    unassigned: rows.filter(r => !r.role).length,
    admins: rows.filter(r => r.is_admin).length,
    verified: rows.filter(r => r.license_submitted).length,
    pendingLicenses: rows.filter(r => !!r.license_url && !r.license_submitted).length,
  }), [rows]);


  if (authLoading || roleLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen">
        <PetrolTicker />
        <Header />
        <div className="mx-auto max-w-md px-4 py-20 text-center">
          <Shield className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Access denied</h1>
          <p className="text-sm text-muted-foreground mb-6">You don't have admin permissions.</p>
          <Link to="/dashboard" className="px-4 py-2 rounded-md bg-gradient-primary text-primary-foreground font-semibold">
            Back to dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <PetrolTicker />
      <Header />
      <div className="mx-auto max-w-7xl px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-primary flex items-center justify-center shadow-glow">
              <Crown className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Admin Control Center</h1>
              <p className="text-xs text-muted-foreground font-mono uppercase tracking-widest">Manage users · roles · verification</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          <StatCard icon={Users} label="Total" value={counts.all} />
          <StatCard icon={Car} label="Drivers" value={counts.drivers} accent="primary" />
          <StatCard icon={User} label="Passengers" value={counts.passengers} accent="primary" />
          <StatCard icon={AlertCircle} label="Unassigned" value={counts.unassigned} accent="warn" />
          <StatCard icon={CheckCircle2} label="Verified" value={counts.verified} accent="success" />
          <StatCard icon={Crown} label="Admins" value={counts.admins} accent="primary" />
        </div>

        {/* Message */}
        {msg && (
          <div className={`mb-4 p-3 rounded-md flex items-center gap-2 text-sm border ${
            msg.type === "ok" ? "bg-primary/10 border-primary/30 text-primary-glow" : "bg-destructive/10 border-destructive/30 text-destructive"
          }`}>
            {msg.type === "ok" ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            {msg.text}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 mb-4 overflow-x-auto pb-1">
          {([
            ["all", "All", counts.all],
            ["unassigned", "Unassigned", counts.unassigned],
            ["drivers", "Drivers", counts.drivers],
            ["passengers", "Passengers", counts.passengers],
            ["licenses", "Licenses", counts.pendingLicenses],
            ["admins", "Admins", counts.admins],
          ] as const).map(([key, label, n]) => (
            <button
              key={key}
              onClick={() => setTab(key as Tab)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-smooth whitespace-nowrap ${
                tab === key ? "bg-primary text-primary-foreground shadow-glow" : "bg-secondary hover:bg-secondary/70 text-muted-foreground"
              } ${key === "licenses" && counts.pendingLicenses > 0 && tab !== "licenses" ? "ring-1 ring-amber-400/60 text-amber-400" : ""}`}
            >
              {label} <span className="opacity-70 text-xs ml-1">({n})</span>
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="glass rounded-xl overflow-hidden shadow-card">
          {loading ? (
            <div className="p-12 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>
          ) : filtered.length === 0 ? (
            <div className="p-12 text-center text-sm text-muted-foreground">
              {tab === "licenses" ? "No license submissions yet." : "No users in this view."}
            </div>
          ) : tab === "licenses" ? (
            <div className="divide-y divide-border/50">
              {filtered.map((r) => (
                <LicenseRow
                  key={r.id}
                  row={r}
                  onVerify={() => toggleVerify(r)}
                  onError={(t: string) => flash("err", t)}
                />
              ))}
            </div>
          ) : (
            <div className="divide-y divide-border/50">
              {filtered.map((r) => (
                <UserRow
                  key={r.id}
                  row={r}
                  isSelf={r.id === user?.id}
                  onAssignDriver={() => setEditing({ ...r, role: "driver" })}
                  onAssignPassenger={() => setRole(r, "passenger")}
                  onUnassign={() => setRole(r, null)}
                  onEditDriver={() => setEditing(r)}
                  onToggleAdmin={() => toggleAdmin(r)}
                  onToggleVerify={() => toggleVerify(r)}
                  onDelete={() => deleteProfile(r)}
                />
              ))}
            </div>
          )}
        </div>

        {/* Help */}
        <div className="mt-6 glass rounded-xl p-5 text-xs text-muted-foreground space-y-2">
          <div className="font-semibold text-foreground flex items-center gap-1.5"><Shield className="w-3.5 h-3.5" /> Admin powers</div>
          <ul className="list-disc list-inside space-y-1 leading-relaxed">
            <li><b>Assign as Driver</b> — sets role and lets you fill vehicle, seats, fuel avg, license verification.</li>
            <li><b>Assign as Passenger</b> — adds the user to the passenger pool for matching.</li>
            <li><b>Unassign</b> — removes the role; user disappears from public listings.</li>
            <li><b>Verify</b> — toggles the green tick on a driver's profile (manual override).</li>
            <li><b>Promote / Demote admin</b> — manage who has access to this panel.</li>
            <li><b>Delete profile</b> — wipes the user's carpool data (auth account remains).</li>
          </ul>
          <div className="font-semibold text-foreground pt-2 flex items-center gap-1.5"><Crown className="w-3.5 h-3.5" /> How to grant admin access</div>
          <p>Any existing admin can promote another signed-in user from this panel using the crown icon. New signups always start as regular users — they cannot self-promote.</p>
        </div>
      </div>

      {editing && (
        <DriverEditor
          row={editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); load(); flash("ok", "Driver details saved"); }}
          onError={(t) => flash("err", t)}
        />
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, accent }: { icon: any; label: string; value: number; accent?: "primary" | "success" | "warn" }) {
  const color = accent === "primary" ? "text-primary-glow" : accent === "success" ? "text-success" : accent === "warn" ? "text-amber-400" : "text-foreground";
  return (
    <div className="glass rounded-lg p-3">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-muted-foreground font-mono">
        <Icon className="w-3 h-3" /> {label}
      </div>
      <div className={`text-2xl font-bold mt-1 ${color}`}>{value}</div>
    </div>
  );
}

function UserRow({
  row, isSelf,
  onAssignDriver, onAssignPassenger, onUnassign, onEditDriver,
  onToggleAdmin, onToggleVerify, onDelete,
}: {
  row: Row; isSelf: boolean;
  onAssignDriver: () => void; onAssignPassenger: () => void; onUnassign: () => void; onEditDriver: () => void;
  onToggleAdmin: () => void; onToggleVerify: () => void; onDelete: () => void;
}) {
  const pickup = PICKUP_POINTS.find(p => p.id === row.pickup_id);
  const shift = SHIFTS.find(s => s.id === row.shift_id);

  const roleBadge = row.role === "driver"
    ? <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-primary/20 text-primary-glow flex items-center gap-1"><Car className="w-3 h-3" />Driver</span>
    : row.role === "passenger"
    ? <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-secondary text-muted-foreground flex items-center gap-1"><User className="w-3 h-3" />Passenger</span>
    : <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400">Unassigned</span>;

  return (
    <div className="p-4 hover:bg-secondary/20 transition-smooth">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="flex-1 min-w-[200px]">
          <div className="font-semibold flex items-center gap-2 flex-wrap">
            {row.name || "—"}
            {roleBadge}
            {row.is_admin && <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-primary/30 text-primary-glow flex items-center gap-1"><Crown className="w-3 h-3" />Admin</span>}
            {row.license_submitted && row.role === "driver" && <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-success/20 text-success flex items-center gap-1"><CheckCircle2 className="w-3 h-3" />Verified</span>}
            {isSelf && <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-card border border-border">You</span>}
          </div>
          <div className="text-xs text-muted-foreground font-mono mt-0.5">{row.phone || "no phone"}</div>
          <div className="text-xs text-muted-foreground mt-1 flex items-center gap-3 flex-wrap">
            {pickup && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{pickup.name}</span>}
            {shift && <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{shift.label}</span>}
            {row.role === "driver" && (
              <span className="font-mono">{row.vehicle ?? "no vehicle"} · {row.average_kmpl ?? "—"} km/L · {row.seats_available ?? "—"} seats</span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap justify-end">
          {row.role !== "driver" && (
            <button onClick={onAssignDriver} className="px-2.5 py-1.5 rounded-md text-xs font-semibold bg-primary/20 text-primary-glow hover:bg-primary/30 flex items-center gap-1">
              <Car className="w-3.5 h-3.5" /> Assign Driver
            </button>
          )}
          {row.role !== "passenger" && (
            <button onClick={onAssignPassenger} className="px-2.5 py-1.5 rounded-md text-xs font-semibold bg-secondary hover:bg-secondary/70 flex items-center gap-1">
              <User className="w-3.5 h-3.5" /> Assign Passenger
            </button>
          )}
          {row.role === "driver" && (
            <>
              <button onClick={onEditDriver} title="Edit driver details" className="p-1.5 rounded hover:bg-secondary">
                <UserCog className="w-4 h-4 text-primary-glow" />
              </button>
              <button onClick={onToggleVerify} title={row.license_submitted ? "Revoke verification" : "Mark verified"} className="p-1.5 rounded hover:bg-secondary">
                <CheckCircle2 className={`w-4 h-4 ${row.license_submitted ? "text-success" : "text-muted-foreground"}`} />
              </button>
            </>
          )}
          {row.role && (
            <button onClick={onUnassign} title="Unassign role" className="p-1.5 rounded hover:bg-secondary">
              <ShieldOff className="w-4 h-4 text-muted-foreground" />
            </button>
          )}
          <button
            onClick={onToggleAdmin}
            disabled={isSelf}
            title={isSelf ? "Can't change your own admin status" : row.is_admin ? "Demote admin" : "Promote to admin"}
            className="p-1.5 rounded hover:bg-secondary disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <Crown className={`w-4 h-4 ${row.is_admin ? "text-primary-glow" : "text-muted-foreground"}`} />
          </button>
          <button
            onClick={onDelete}
            disabled={isSelf}
            title={isSelf ? "Can't delete yourself" : "Delete profile"}
            className="p-1.5 rounded hover:bg-destructive/20 hover:text-destructive disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

function DriverEditor({ row, onClose, onSaved, onError }: { row: Row; onClose: () => void; onSaved: () => void; onError: (t: string) => void }) {
  const [vehicle, setVehicle] = useState(row.vehicle ?? "");
  const [avg, setAvg] = useState<string>(row.average_kmpl?.toString() ?? "");
  const [seats, setSeats] = useState<string>(row.seats_available?.toString() ?? "");
  const [verified, setVerified] = useState(row.license_submitted);
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    const { error } = await supabase.from("profiles").update({
      role: "driver",
      vehicle: vehicle || null,
      average_kmpl: avg ? Number(avg) : null,
      seats_available: seats ? Number(seats) : null,
      license_submitted: verified,
    }).eq("id", row.id);
    setSaving(false);
    if (error) return onError(error.message);
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="glass rounded-2xl p-6 w-full max-w-md shadow-elevated" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Car className="w-5 h-5 text-primary-glow" />
            <h2 className="font-bold">Driver Details — {row.name}</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-secondary rounded"><X className="w-4 h-4" /></button>
        </div>
        <div className="space-y-4">
          <Input label="Vehicle (Make / Model / Year)" value={vehicle} onChange={setVehicle} placeholder="Honda City 2020" />
          <div className="grid grid-cols-2 gap-3">
            <Input label="Average (km/L)" value={avg} onChange={setAvg} type="number" placeholder="13" />
            <Input label="Seats Available" value={seats} onChange={setSeats} type="number" placeholder="3" />
          </div>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} className="w-4 h-4" />
            <CheckCircle2 className={`w-4 h-4 ${verified ? "text-success" : "text-muted-foreground"}`} />
            Mark as verified (license confirmed)
          </label>
          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 py-2.5 rounded-lg bg-secondary hover:bg-secondary/70 text-sm font-semibold">Cancel</button>
            <button onClick={save} disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gradient-primary text-primary-foreground text-sm font-semibold flex items-center justify-center gap-1.5 disabled:opacity-50">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Save className="w-4 h-4" /> Save</>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Input({ label, value, onChange, type = "text", placeholder }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-mono mb-1">{label}</div>
      <input
        type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
        className="w-full px-3 py-2 rounded-lg bg-input border border-border focus:outline-none focus:ring-2 focus:ring-ring text-sm"
      />
    </div>
  );
}

function LicenseRow({ row, onVerify, onError }: { row: Row; onVerify: () => void; onError: (t: string) => void }) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [revoking, setRevoking] = useState(false);

  async function viewLicense() {
    if (!row.license_url) return;
    setLoading(true);
    const { data, error } = await supabase.storage
      .from("licenses")
      .createSignedUrl(row.license_url, 300);
    setLoading(false);
    if (error || !data) return onError(error?.message ?? "Could not load license");
    setSignedUrl(data.signedUrl);
    window.open(data.signedUrl, "_blank", "noopener,noreferrer");
  }

  async function reject() {
    if (!confirm(`Reject ${row.name}'s license submission? They will need to re-upload it.`)) return;
    setRevoking(true);
    // Clear license_url and ensure not verified
    const { error } = await supabase.from("profiles").update({
      license_url: null,
      license_submitted: false,
    }).eq("id", row.id);
    setRevoking(false);
    if (error) return onError(error.message);
    // Best-effort: remove file from storage
    if (row.license_url) {
      await supabase.storage.from("licenses").remove([row.license_url]);
    }
  }

  return (
    <div className="p-4 hover:bg-secondary/20 transition-smooth">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="flex-1 min-w-[200px]">
          <div className="font-semibold flex items-center gap-2 flex-wrap">
            {row.name || "—"}
            {row.license_submitted ? (
              <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-success/20 text-success flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Verified
              </span>
            ) : (
              <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 flex items-center gap-1">
                <FileCheck2 className="w-3 h-3" /> Pending review
              </span>
            )}
            {row.role === "driver" && (
              <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-primary/20 text-primary-glow flex items-center gap-1">
                <Car className="w-3 h-3" /> Driver
              </span>
            )}
          </div>
          <div className="text-xs text-muted-foreground font-mono mt-0.5">{row.phone || "no phone"}</div>
          <div className="text-xs text-muted-foreground mt-1 font-mono truncate">{row.license_url}</div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap justify-end">
          <button
            onClick={viewLicense}
            disabled={loading}
            className="px-2.5 py-1.5 rounded-md text-xs font-semibold bg-secondary hover:bg-secondary/70 flex items-center gap-1 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Eye className="w-3.5 h-3.5" />} View license
          </button>
          {!row.license_submitted && (
            <button
              onClick={onVerify}
              className="px-2.5 py-1.5 rounded-md text-xs font-semibold bg-success/20 text-success hover:bg-success/30 flex items-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" /> Verify
            </button>
          )}
          {row.license_submitted && (
            <button
              onClick={onVerify}
              className="px-2.5 py-1.5 rounded-md text-xs font-semibold bg-secondary hover:bg-secondary/70 flex items-center gap-1"
            >
              <ShieldOff className="w-3.5 h-3.5" /> Revoke
            </button>
          )}
          <button
            onClick={reject}
            disabled={revoking}
            className="px-2.5 py-1.5 rounded-md text-xs font-semibold bg-destructive/15 text-destructive hover:bg-destructive/25 flex items-center gap-1 disabled:opacity-50"
          >
            {revoking ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <XCircle className="w-3.5 h-3.5" />} Reject
          </button>
        </div>
      </div>
      {signedUrl && (
        <div className="mt-2 text-[10px] text-muted-foreground font-mono">
          Signed URL valid for 5 minutes. <a href={signedUrl} target="_blank" rel="noopener noreferrer" className="text-primary-glow underline">Open again</a>
        </div>
      )}
    </div>
  );
}
