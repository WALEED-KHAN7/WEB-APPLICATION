import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/Header";
import { PetrolTicker } from "@/components/PetrolTicker";
import { PICKUP_POINTS, SHIFTS } from "@/lib/maju-data";
import { useAuth, usePetrolPrice, type Profile } from "@/lib/use-user";
import { computeRideCost, fmtPKR } from "@/lib/ride-math";
import { supabase } from "@/integrations/supabase/client";
import {
  Car, Download, MapPin, ShieldCheck, Users, Clock, Fuel, Calculator,
  Loader2, Wifi, Phone, Sparkles,
} from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — MAJU Carpool" },
      { name: "description", content: "Live matched rides for MAJU students." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading } = useAuth();
  const petrol = usePetrolPrice();
  const [pickupId, setPickupId] = useState<string>("");
  const [shiftId, setShiftId] = useState<string>("");
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  // Gate: redirect to /auth if not signed in
  useEffect(() => {
    if (!authLoading && !user) {
      toast.error("Please sign in first.");
      navigate({ to: "/auth" });
    }
  }, [authLoading, user, navigate]);

  // Initial fetch + realtime subscription
  useEffect(() => {
    if (!user) return;
    let mounted = true;

    (async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("profile_completed", true)
        .order("created_at", { ascending: false });
      if (!mounted) return;
      if (error) console.error("[profiles fetch]", error);
      setProfiles((data as Profile[]) ?? []);
      setLoadingData(false);
    })();

    const channel = supabase
      .channel("profiles-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, (payload) => {
        setProfiles((curr) => {
          if (payload.eventType === "DELETE") {
            return curr.filter((p) => p.id !== (payload.old as any).id);
          }
          const next = payload.new as Profile;
          if (!next.profile_completed) {
            return curr.filter((p) => p.id !== next.id);
          }
          const idx = curr.findIndex((p) => p.id === next.id);
          if (idx === -1) return [next, ...curr];
          const copy = [...curr];
          copy[idx] = next;
          return copy;
        });
      })
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, [user]);

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary-glow" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <PetrolTicker />
      <Header />
      <div className="mx-auto max-w-6xl px-4 py-8 sm:py-10">
        {!profile?.profile_completed ? (
          <ProfileIncomplete />
        ) : (
          <>
            <WelcomeCard profile={profile} />
            <FilterBar pickupId={pickupId} shiftId={shiftId} onPickup={setPickupId} onShift={setShiftId} />
            {loadingData ? (
              <div className="glass rounded-xl p-10 text-center">
                <Loader2 className="w-6 h-6 animate-spin text-primary-glow mx-auto" />
                <div className="text-sm text-muted-foreground mt-2">Loading live data…</div>
              </div>
            ) : (
              <MatchesGrid me={profile} all={profiles} pickupId={pickupId} shiftId={shiftId} petrol={petrol} />
            )}
          </>
        )}
      </div>
    </div>
  );
}

function ProfileIncomplete() {
  return (
    <div className="glass rounded-2xl p-10 text-center">
      <h2 className="text-2xl font-bold">Finish setting up your profile</h2>
      <p className="text-muted-foreground mt-2">Tell us your pickup point and class shift so we can find matches.</p>
      <Link to="/register" className="inline-flex mt-6 px-6 py-3 rounded-lg bg-gradient-primary text-primary-foreground font-semibold shadow-glow">
        Complete Profile
      </Link>
    </div>
  );
}

function WelcomeCard({ profile }: { profile: Profile }) {
  return (
    <div className="glass rounded-2xl p-5 sm:p-6 mb-6 flex flex-wrap items-center justify-between gap-4">
      <div>
        <div className="text-xs font-mono text-primary-glow uppercase tracking-widest flex items-center gap-2">
          {profile.role === "driver" ? "Driver Account" : "Passenger Account"}
          <span className="inline-flex items-center gap-1 text-success">
            <Wifi className="w-3 h-3" /> Live
          </span>
        </div>
        <div className="text-xl sm:text-2xl font-bold mt-1">Welcome, {profile.name.split(" ")[0] || "Student"}</div>
        <div className="text-xs text-muted-foreground mt-1">
          {PICKUP_POINTS.find(p => p.id === profile.pickup_id)?.name} • {SHIFTS.find(s => s.id === profile.shift_id)?.label}
        </div>
      </div>
      {profile.role === "driver" && (
        <div className="flex items-center gap-4 text-xs">
          <Stat label="Vehicle" value={profile.vehicle || "—"} />
          <Stat label="Avg" value={`${profile.average_kmpl ?? "—"} km/L`} />
          <Stat label="Seats" value={String(profile.seats_available ?? "—")} />
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-semibold text-sm">{value}</div>
    </div>
  );
}

function FilterBar({ pickupId, shiftId, onPickup, onShift }: { pickupId: string; shiftId: string; onPickup: (v: string) => void; onShift: (v: string) => void; }) {
  return (
    <div className="glass rounded-2xl p-5 mb-6 grid sm:grid-cols-2 gap-4">
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1.5 font-semibold flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5" /> Pickup Hotspot
        </div>
        <select value={pickupId} onChange={(e) => onPickup(e.target.value)} className={inputCls}>
          <option value="">All pickup points</option>
          {PICKUP_POINTS.map((p) => (
            <option key={p.id} value={p.id}>{p.name} ({p.distanceKm} km)</option>
          ))}
        </select>
      </div>
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1.5 font-semibold flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5" /> Class Shift
        </div>
        <select value={shiftId} onChange={(e) => onShift(e.target.value)} className={inputCls}>
          <option value="">All shifts</option>
          {SHIFTS.map((s) => (
            <option key={s.id} value={s.id}>{s.label}</option>
          ))}
        </select>
      </div>
    </div>
  );
}

function MatchesGrid({ me, all, pickupId, shiftId, petrol }: { me: Profile; all: Profile[]; pickupId: string; shiftId: string; petrol: number; }) {
  const matches = useMemo(() => {
    return all.filter((u) => {
      if (u.id === me.id) return false; // hide self
      if (pickupId && u.pickup_id !== pickupId) return false;
      if (shiftId && u.shift_id !== shiftId) return false;
      return true;
    });
  }, [all, pickupId, shiftId, me.id]);

  const drivers = matches.filter((m) => m.role === "driver");
  const passengers = matches.filter((m) => m.role === "passenger");

  return (
    <div className="space-y-8">
      <SampleRides petrol={petrol} />

      <section>
        <SectionTitle icon={Car} title={`Available Drivers (${drivers.length})`} subtitle="Tap a driver card to view ride summary and download details" />
        {drivers.length === 0 ? (
          <Empty msg="No drivers match this filter yet. Try a different pickup point or shift." />
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {drivers.map((d) => (
              <DriverCard key={d.id} driver={d}
                passengerCount={passengers.filter(p => p.pickup_id === d.pickup_id && p.shift_id === d.shift_id).length}
                petrol={petrol} viewer={me} />
            ))}
          </div>
        )}
      </section>

      <section>
        <SectionTitle icon={Users} title={`Passengers (${passengers.length})`} subtitle="Students waiting at matching pickup and shift" />
        {passengers.length === 0 ? (
          <Empty msg="No passengers found for this filter." />
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {passengers.map((p) => {
              const point = PICKUP_POINTS.find((pp) => pp.id === p.pickup_id);
              const shift = SHIFTS.find((s) => s.id === p.shift_id);
              return (
                <div key={p.id} className="glass rounded-xl p-4 hover:border-primary/40 transition-smooth">
                  <div className="flex items-center gap-3">
                    <Avatar name={p.name} />
                    <div className="min-w-0">
                      <div className="font-semibold truncate">{p.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{point?.name}</div>
                      <div className="text-xs text-muted-foreground">{shift?.label}</div>
                      {p.phone && (
                        <div className="text-xs text-primary-glow font-mono mt-1 flex items-center gap-1">
                          <Phone className="w-3 h-3" /> {p.phone}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}

function SectionTitle({ icon: Icon, title, subtitle }: { icon: any; title: string; subtitle: string }) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-2">
        <Icon className="w-5 h-5 text-primary-glow" />
        <h2 className="text-xl font-bold">{title}</h2>
      </div>
      <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>
    </div>
  );
}

function Empty({ msg }: { msg: string }) {
  return <div className="glass rounded-xl p-6 text-sm text-muted-foreground text-center">{msg}</div>;
}

function Avatar({ name }: { name: string }) {
  const initials = (name || "?").split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
  return (
    <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center text-primary-foreground font-bold text-sm shadow-glow shrink-0">
      {initials}
    </div>
  );
}

function DriverCard({ driver, passengerCount, petrol, viewer }: { driver: Profile; passengerCount: number; petrol: number; viewer: Profile; }) {
  const pointMaybe = PICKUP_POINTS.find((p) => p.id === driver.pickup_id);
  const shiftMaybe = SHIFTS.find((s) => s.id === driver.shift_id);
  if (!pointMaybe || !shiftMaybe) return null;
  const point = pointMaybe;
  const shift = shiftMaybe;
  const seats = driver.seats_available ?? 1;
  const avg = driver.average_kmpl ?? 12;
  const totalPeople = Math.min(passengerCount, seats) + 1;
  const calc = computeRideCost({
    oneWayKm: point.distanceKm,
    averageKmpl: avg,
    totalPeople,
    petrolPrice: petrol,
  });

  function downloadDetails() {
    const lines = [
      "═══════════════════════════════════════════",
      "  MAJU CARPOOL — RIDE DETAILS",
      "═══════════════════════════════════════════",
      "",
      `Issued To       : ${viewer.name}`,
      `Issued At       : ${new Date().toLocaleString()}`,
      "",
      "── DRIVER ─────────────────────────────────",
      `Name            : ${driver.name}`,
      `Verified        : ${driver.license_submitted ? "YES (License submitted)" : "NO"}`,
      `Vehicle         : ${driver.vehicle}`,
      `Avg Consumption : ${avg} km/L`,
      `Seats Available : ${seats}`,
      driver.phone ? `Contact         : ${driver.phone}` : "",
      "",
      "── RIDE ───────────────────────────────────",
      `Pickup Point    : ${point.name}`,
      `Area            : ${point.area}`,
      `Destination     : MAJU University, Main Shahrah-e-Faisal`,
      `Class Shift     : ${shift.label}`,
      "",
      "── COST CALCULATION ──────────────────────",
      `One-way Distance: ${point.distanceKm} km`,
      `Round Trip      : ${calc.distance.toFixed(2)} km`,
      `Fuel Required   : ${calc.litres.toFixed(2)} L  (distance ÷ avg)`,
      `Petrol Price    : Rs ${calc.petrol.toFixed(2)} / L  (live)`,
      `Total Fuel Cost : ${fmtPKR(calc.totalCost)}`,
      `People in Ride  : ${totalPeople} (1 driver + ${totalPeople - 1} passenger${totalPeople - 1 === 1 ? "" : "s"})`,
      `─────────────────────────────────────────`,
      `PER PERSON      : ${fmtPKR(calc.perPerson)}`,
      `─────────────────────────────────────────`,
      "",
      "Formula: (distance ÷ vehicle_avg) × petrol_price ÷ people",
      "",
      "Generated by MAJU Carpool",
    ].filter(Boolean);
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `MAJU-Ride-${driver.name.replace(/\s+/g, "-")}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="glass rounded-2xl p-5 shadow-card hover:shadow-elevated hover:-translate-y-0.5 transition-smooth flex flex-col">
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="flex items-center gap-3 min-w-0">
          <Avatar name={driver.name} />
          <div className="min-w-0">
            <div className="font-semibold truncate flex items-center gap-1.5">
              {driver.name}
              {driver.license_submitted && (
                <span title="Verified driver — license on file" className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] bg-success/15 text-success border border-success/30 font-mono uppercase">
                  <ShieldCheck className="w-3 h-3" /> Verified
                </span>
              )}
            </div>
            <div className="text-xs text-muted-foreground truncate">{driver.vehicle}</div>
            {driver.phone && (
              <div className="text-[11px] text-primary-glow font-mono flex items-center gap-1 mt-0.5">
                <Phone className="w-3 h-3" /> {driver.phone}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 text-xs mb-4">
        <Pill label="Seats" value={String(seats)} />
        <Pill label="Avg" value={`${avg} km/L`} />
        <Pill label="Distance" value={`${point.distanceKm} km`} />
      </div>

      <div className="text-xs space-y-1 mb-4 font-mono bg-card/50 rounded-lg p-3 border border-border">
        <div className="flex justify-between"><span className="text-muted-foreground">Pickup</span><span className="truncate ml-2 text-right">{point.name}</span></div>
        <div className="flex justify-between"><span className="text-muted-foreground">Shift</span><span>{shift.label}</span></div>
        <div className="flex justify-between"><span className="text-muted-foreground">Riders</span><span>{totalPeople}</span></div>
      </div>

      <div className="rounded-xl bg-gradient-primary p-4 text-primary-foreground mb-4 shadow-glow">
        <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-widest opacity-90">
          <Calculator className="w-3 h-3" /> Suggested Contribution
        </div>
        <div className="text-2xl font-bold mt-1">{fmtPKR(calc.perPerson)}</div>
        <div className="text-[11px] opacity-90 mt-1 font-mono">
          ({calc.distance.toFixed(1)} km ÷ {avg} km/L) × Rs {petrol.toFixed(2)} ÷ {totalPeople}
        </div>
        <div className="text-[10px] opacity-75 mt-1.5 flex items-center gap-1">
          <Fuel className="w-3 h-3" /> Total fuel: {fmtPKR(calc.totalCost)} • {calc.litres.toFixed(2)} L
        </div>
      </div>

      <button
        onClick={downloadDetails}
        className="mt-auto inline-flex items-center justify-center gap-2 py-2.5 rounded-lg bg-secondary hover:bg-secondary/80 border border-border hover:border-primary/50 text-sm font-semibold transition-smooth"
      >
        <Download className="w-4 h-4" /> Download Ride Details
      </button>
    </div>
  );
}

function Pill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-card/60 border border-border p-2 text-center">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-semibold text-sm">{value}</div>
    </div>
  );
}

const inputCls = "w-full px-3.5 py-2.5 rounded-lg bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-smooth";

const DEMO_RIDES = [
  { driver: "Ahmed Raza", pickup: "NIPA (Mazaidar Haleem)", distanceKm: 9.5, shift: "Morning — 8:00 AM", seats: 3, vehicle: "Honda City 2019", avg: 13 },
  { driver: "Hassan Ali", pickup: "Nursery (KFC)", distanceKm: 4.2, shift: "Morning — 10:00 AM", seats: 2, vehicle: "Suzuki Cultus 2021", avg: 15 },
  { driver: "Zain Malik", pickup: "Millennium Mall (Main Gate)", distanceKm: 6.8, shift: "Noon — 12:00 PM", seats: 4, vehicle: "Toyota Corolla 2020", avg: 12 },
];

function SampleRides({ petrol }: { petrol: number }) {
  return (
    <section>
      <SectionTitle icon={Sparkles} title="Sample Rides" subtitle="Example carpool offers — sign up real drivers to see live matches" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {DEMO_RIDES.map((r) => {
          const totalPeople = Math.min(r.seats, 2) + 1;
          const calc = computeRideCost({
            oneWayKm: r.distanceKm,
            averageKmpl: r.avg,
            totalPeople,
            petrolPrice: petrol,
          });
          return (
            <div key={r.driver} className="glass rounded-2xl p-5 shadow-card flex flex-col border-dashed">
              <div className="flex items-center gap-3 mb-3">
                <Avatar name={r.driver} />
                <div className="min-w-0">
                  <div className="font-semibold flex items-center gap-1.5">
                    {r.driver}
                    <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-muted text-muted-foreground">Demo</span>
                  </div>
                  <div className="text-xs text-muted-foreground truncate">{r.vehicle}</div>
                </div>
              </div>
              <div className="text-xs space-y-1 mb-3 font-mono bg-card/50 rounded-lg p-3 border border-border">
                <div className="flex justify-between"><span className="text-muted-foreground">Pickup</span><span className="truncate ml-2 text-right">{r.pickup}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Shift</span><span>{r.shift}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Seats</span><span>{r.seats}</span></div>
              </div>
              <div className="rounded-xl bg-gradient-primary p-4 text-primary-foreground shadow-glow">
                <div className="text-[10px] font-mono uppercase tracking-widest opacity-90">Estimated Fare</div>
                <div className="text-2xl font-bold mt-1">{fmtPKR(calc.perPerson)}</div>
                <div className="text-[10px] opacity-75 mt-1">per person · round trip</div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
