import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { PetrolTicker } from "@/components/PetrolTicker";
import { ArrowRight, Calculator, MapPin, ShieldCheck, Users, Zap, Car } from "lucide-react";
import { PICKUP_POINTS } from "@/lib/maju-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MAJU Carpool — Smart Ridesharing for MAJU Students" },
      { name: "description", content: "Pair MAJU drivers and passengers by pickup point and class shift. Auto-split petrol costs with live price tracking." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="min-h-screen">
      <PetrolTicker />
      <Header />

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
        <div className="mx-auto max-w-6xl px-4 pt-16 pb-24 sm:pt-24 sm:pb-32 relative">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs font-mono uppercase tracking-widest text-primary-glow mb-6 animate-fade-up">
            <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
            Beta • Karachi Campus
          </div>
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05] max-w-3xl animate-fade-up" style={{ animationDelay: "0.1s" }}>
            Share the ride.<br />
            <span className="text-gradient">Split the petrol.</span>
          </h1>
          <p className="mt-6 text-base sm:text-lg text-muted-foreground max-w-xl animate-fade-up" style={{ animationDelay: "0.2s" }}>
            MAJU Carpool intelligently pairs drivers and passengers from <strong className="text-foreground">your pickup point</strong> on <strong className="text-foreground">your class shift</strong> — heading straight to MAJU on Main Shahrah-e-Faisal.
          </p>
          <div className="mt-8 flex flex-wrap gap-3 animate-fade-up" style={{ animationDelay: "0.3s" }}>
            <Link
              to="/register"
              className="group inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-primary text-primary-foreground font-semibold shadow-elevated hover:scale-[1.02] transition-smooth"
            >
              Get Started <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </Link>
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg glass text-foreground font-semibold hover:bg-secondary transition-smooth"
            >
              Find a Ride
            </Link>
          </div>

          <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl animate-fade-up" style={{ animationDelay: "0.4s" }}>
            {[
              { k: "7", v: "Pickup Hotspots" },
              { k: "Live", v: "Petrol Pricing" },
              { k: "Auto", v: "Bill Splitting" },
              { k: "100%", v: "MAJU Verified" },
            ].map((s) => (
              <div key={s.v} className="glass rounded-lg p-4">
                <div className="text-2xl font-bold text-gradient">{s.k}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-4 pb-20">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { icon: MapPin, title: "7 Verified Hotspots", desc: "From NIPA & Sohrab Goth to Star Gate, Karsaz, and right on Shahrah-e-Faisal." },
            { icon: Users, title: "Shift Matching", desc: "We pair students on the same class timing so your ride actually fits your schedule." },
            { icon: Calculator, title: "Transparent Math", desc: "(Distance ÷ Vehicle Avg) × Live Petrol Price, split evenly. No surprises." },
            { icon: ShieldCheck, title: "Verified Drivers", desc: "License-submitted drivers get a security badge on their cards." },
            { icon: Zap, title: "Live Petrol Ticker", desc: "Fares auto-update as prices fluctuate — always current to the rupee." },
            { icon: Car, title: "Driver Profiles", desc: "See vehicle, seats available, and km/L average before you book." },
          ].map((f, i) => (
            <div
              key={f.title}
              className="glass rounded-xl p-5 hover:border-primary/50 transition-smooth animate-fade-up"
              style={{ animationDelay: `${0.05 * i}s` }}
            >
              <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center mb-3">
                <f.icon className="w-5 h-5 text-primary-glow" />
              </div>
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>

        {/* Pickup map list */}
        <div className="mt-16 glass rounded-2xl p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
            <div>
              <h2 className="text-2xl font-bold">Pickup Network</h2>
              <p className="text-sm text-muted-foreground">Distances measured one-way to MAJU main campus.</p>
            </div>
            <div className="text-xs font-mono text-primary-glow px-3 py-1 rounded-full bg-primary/10 border border-primary/30">
              MAIN SHAHRAH-E-FAISAL
            </div>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {PICKUP_POINTS.map((p) => (
              <div key={p.id} className="rounded-lg border border-border bg-card/40 p-4 flex items-center justify-between hover:border-primary/40 transition-smooth">
                <div className="min-w-0">
                  <div className="font-medium truncate">{p.name}</div>
                  <div className="text-xs text-muted-foreground">{p.area}</div>
                </div>
                <div className="text-right shrink-0 ml-3">
                  <div className="font-mono text-primary-glow font-bold">{p.distanceKm}<span className="text-xs text-muted-foreground"> km</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground font-mono">
        © 2026 MAJU Carpool — Karachi Campus.
      </footer>
    </div>
  );
}
